/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package csbttourneydataparser;

import csbttourneydataparser.data.Bowler;
import csbttourneydataparser.data.Entry;
import csbttourneydataparser.data.Game;
import csbttourneydataparser.data.Tournament;
import java.text.SimpleDateFormat;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.*;

// Apache POI - HSSF imports
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author macgasm
 */
public class CSBTTourneyDataParser {

    private XSSFWorkbook book;
    private List<Tournament> tourneys;

    public CSBTTourneyDataParser(XSSFWorkbook book) {
        this.book = book;
        this.tourneys = new ArrayList<>();
    }

    public void doWork() {
        Tournament currentTourney = null;
                 //this.book.getNumberOfSheets()
                 
        for (int sheets = 0; sheets < this.book.getNumberOfSheets() - 1; sheets++) {
            
            XSSFRow row = this.book.getSheetAt(sheets).getRow(0);

            //currentTourney = new Tournament("", this.book.getSheetAt(sheets).getSheetName(), "", "", "");
            currentTourney = new Tournament(row.getCell(0).getStringCellValue(),
                    Integer.toString((int) (row.getCell(1).getNumericCellValue())),
                    row.getCell(2).getStringCellValue(),
                    row.getCell(3).getStringCellValue(),
                    row.getCell(4).getStringCellValue(),
                    row.getCell(5).getStringCellValue(),
                    row.getCell(6).getStringCellValue());

            switch (row.getCell(6).getStringCellValue()) {
                case "Standard":
                    this.parseStandardTourney(currentTourney, this.book.getSheetAt(sheets));
                    break;
                case "Match Play":
                    break;
                case "Round Robin":
                    break;
            }

            this.loadToMySQL(currentTourney);

            this.tourneys.add(currentTourney);
        }
    }

    private void parseStandardTourney(Tournament currentTourney, XSSFSheet tourneySheet) {
        int numRows = tourneySheet.getPhysicalNumberOfRows();

        //Tournament currentTourney = null;
        Bowler currentBowler = null;
        Entry currentEntry = null;

        int currentRow;

        //parse the qualifying
        for (currentRow = 2; currentRow < numRows; currentRow++) {
            //data comes in the following order:
            // Bowler	 Game 1	 Game 2	 Game 3	 Game 4	 Game 5	 Game 6	
            XSSFRow row = tourneySheet.getRow(currentRow);

            if (row != null && row.getCell(0) != null && row.getCell(0).getStringCellValue().equals("")) {
                //done with the qual, break
                break;
            }

            String[] name = row.getCell(0).getStringCellValue().split(" ", 2);
            currentBowler = new Bowler(name[0], name[1]);

            currentEntry = new Entry(currentBowler);
            currentEntry.addGame(new Game((int) row.getCell(1).getNumericCellValue(), "q1"));
            currentEntry.addGame(new Game((int) row.getCell(2).getNumericCellValue(), "q2"));
            currentEntry.addGame(new Game((int) row.getCell(3).getNumericCellValue(), "q3"));
            currentEntry.addGame(new Game((int) row.getCell(4).getNumericCellValue(), "q4"));
            currentEntry.addGame(new Game((int) row.getCell(5).getNumericCellValue(), "q5"));
            currentEntry.addGame(new Game((int) row.getCell(6).getNumericCellValue(), "q6"));
            
            if(row.getCell(7) != null)
            {
                String cutVal = row.getCell(7).getStringCellValue();

                switch(cutVal)
                {
                    case "CUT":
                        currentEntry.isQualCut = true;
                        break;
                    case "SR":
                        currentEntry.isHighSenior = true;
                        currentTourney.highSenior = currentEntry;
                        break;
                    case "FM":
                        currentEntry.isHighWoman = true;
                        currentTourney.highWoman = currentEntry;
                        break;
                }
            }
            
            currentBowler.addEntry(currentEntry);
            currentTourney.addEntry(currentEntry);
        }

        //now parse the semis
        for (currentRow = currentRow + 1; currentRow < numRows; currentRow++) {
            //data comes in the following order:
            // Bowler	 Game 1	 Game 2	 Game 3
            XSSFRow row = tourneySheet.getRow(currentRow);

            if (row == null || row.getCell(0) == null || row.getCell(0).getStringCellValue().equals("")) {
                //done with the semis, break
                break;
            }

            String[] name = row.getCell(0).getStringCellValue().split(" ", 2);
            Bowler tempBowler = new Bowler(name[0], name[1]);
            Entry tempEntry = new Entry(tempBowler);


            currentEntry = currentTourney.entries.get(currentTourney.entries.indexOf(tempEntry));

            currentEntry.addGame(new Game((int) row.getCell(1).getNumericCellValue(), "se1"));
            currentEntry.addGame(new Game((int) row.getCell(2).getNumericCellValue(), "se2"));
            currentEntry.addGame(new Game((int) row.getCell(3).getNumericCellValue(), "se3"));
            
            if(row.getCell(4) != null)
            {
                String cutVal = row.getCell(4).getStringCellValue();

                switch(cutVal)
                {
                    case "CUT":
                        currentEntry.isSemiCut = true;
                        break;
                }
            }
        }

        //parse the stepladder
        currentRow = currentRow + 1;

        for (int game = 1; game <= 4; game++) {
            XSSFRow row = tourneySheet.getRow(currentRow);

            //bowler 1
            String[] name = row.getCell(0).getStringCellValue().split(" ", 2);
            Bowler tempBowler = new Bowler(name[0], name[1]);
            Entry tempEntry = new Entry(tempBowler);

            currentEntry = currentTourney.entries.get(currentTourney.entries.indexOf(tempEntry));
            currentEntry.addGame(new Game((int) row.getCell(1).getNumericCellValue(), "sl" + game));
            
            if(row.getCell(2) != null)
            {
                String cutVal = row.getCell(2).getStringCellValue();

                switch(cutVal)
                {
                    case "WINNER":
                        currentEntry.isWinner = true;
                        currentTourney.winner = currentEntry;
                        currentEntry.stepladderWins++;
                        break;
                    case "SECOND":
                        currentEntry.isSecond = true;
                        currentTourney.second = currentEntry;
                        break;
                }
            }
            
            //go to next bowler
            currentRow++;

            //bowler 2
            row = tourneySheet.getRow(currentRow);
            name = row.getCell(0).getStringCellValue().split(" ", 2);
            tempBowler = new Bowler(name[0], name[1]);
            tempEntry = new Entry(tempBowler);

            currentEntry = currentTourney.entries.get(currentTourney.entries.indexOf(tempEntry));
            currentEntry.addGame(new Game((int) row.getCell(1).getNumericCellValue(), "sl" + game));

            if(row.getCell(2) != null)
            {
                String cutVal = row.getCell(2).getStringCellValue();

                switch(cutVal)
                {
                    case "WINNER":
                        currentEntry.isWinner = true;
                        currentTourney.winner = currentEntry;
                        currentEntry.stepladderWins++;
                        break;
                    case "SECOND":
                        currentEntry.isSecond = true;
                        currentTourney.second = currentEntry;
                        break;
                }
            }
            
            //jump to the space, then to the next bowler
            currentRow += 2;
        }
    }

    private void loadToMySQL(Tournament tourney) {
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        ResultSet idrs = null;
                
        String url = "jdbc:mysql://localhost:3306/CSBT_v1_development";
        String user = "root";
        String password = "password";

        
        int tourneyId = -1;
        int bowlingCenterId = -1;
        int oilPatternId = -1;
        int bowlerId = -1;
        int entryId = -1;
        int gameId = -1;
        
        try {
            con = DriverManager.getConnection(url, user, password);

            st = con.createStatement();
            rs = st.executeQuery("SELECT VERSION()");

            String queryStr = "";

            //get the id of the bowling center
            queryStr = "SELECT id FROM bowling_centers b WHERE b.name = '" + 
                        tourney.bowlingCenter + "' AND b.url = '" +
                        tourney.bowlingCenterURL + "'";
                
            rs = st.executeQuery(queryStr);

            if(rs.next())
            {
                bowlingCenterId = rs.getInt("id");
            }
            else
            {
                queryStr = "INSERT INTO bowling_centers(name, url, created_at, updated_at) VALUES( '" +
                        tourney.bowlingCenter + "', '" +
                        tourney.bowlingCenterURL + "', '"
                        + CSBTTourneyDataParser.now() + "', '"
                        + CSBTTourneyDataParser.now() + "')";

                st.execute(queryStr);
                
                queryStr = "SELECT LAST_INSERT_ID()";
                
                idrs = st.executeQuery(queryStr);
                
                if(idrs.next())
                {
                    bowlingCenterId = idrs.getInt(1);  
                }
            }
            

            //get the id of the oil pattern
            queryStr = "SELECT id FROM oil_patterns o WHERE o.name = '" + 
                        tourney.oilPattern + "' AND o.url = '" +
                        tourney.oilPatternURL + "'";
                
            rs = st.executeQuery(queryStr);

            if(rs.next())
            {
                oilPatternId = rs.getInt("id");
            }
            else
            {
                queryStr = "INSERT INTO oil_patterns(name, url, created_at, updated_at) VALUES( '" +
                        tourney.oilPattern + "', '" +
                        tourney.oilPatternURL + "', '"
                        + CSBTTourneyDataParser.now() + "', '"
                        + CSBTTourneyDataParser.now() + "')";

                st.execute(queryStr);
                
                queryStr = "SELECT LAST_INSERT_ID()";
                
                idrs = st.executeQuery(queryStr);
                
                if(idrs.next())
                {
                    oilPatternId = idrs.getInt(1);  
                }
            }
            
            //create the tourney
            queryStr = "INSERT INTO tournaments(bowling_center_id, oil_pattern_id, winner_id, runner_up_id, top_woman_id, top_senior_id, name, date, format, created_at, updated_at) VALUES("
                    + bowlingCenterId + ", "
                    + oilPatternId + ", "
                    + "-1" + ", "
                    + "-1" + ", "
                    + "-1" + ", "
                    + "-1" + ", '"
                    + tourney.name + "', "
                    + tourney.date + ", '"
                    + tourney.format + "', '"
                    + CSBTTourneyDataParser.now() + "', '"
                    + CSBTTourneyDataParser.now() + "')";

            st.execute(queryStr);
            
            queryStr = "SELECT LAST_INSERT_ID()";

            idrs = st.executeQuery(queryStr);

            if(idrs.next())
            {
                tourneyId = idrs.getInt(1);  
            }

            //create the bowlers
            Bowler tempBowler = null;
            
            for(Entry e : tourney.entries)
            {
                tempBowler = e.bowler;
                
                //see if the bowler exists and add it
                queryStr = "SELECT id FROM bowlers b WHERE b.first_name = '" + 
                        tempBowler.firstName + "' AND b.last_name = '" +
                        tempBowler.lastName + "'";
                
                rs = st.executeQuery(queryStr);
                
                if(rs.next())
                {
                    bowlerId = rs.getInt("id");
                }
                else
                {
                    queryStr = "INSERT INTO bowlers(first_name, last_name, created_at, updated_at) VALUES( '" +
                            tempBowler.firstName + "', '" +
                            tempBowler.lastName + "', '"
                            + CSBTTourneyDataParser.now() + "', '"
                            + CSBTTourneyDataParser.now() + "')";
                    
                    st.execute(queryStr);
                
                    queryStr = "SELECT LAST_INSERT_ID()";

                    idrs = st.executeQuery(queryStr);

                    if(idrs.next())
                    {
                        bowlerId = idrs.getInt(1);  
                    }
                }
                
                //create the entry
                queryStr = "INSERT INTO entries(tournament_id, bowler_id, is_qual_cut, is_semi_cut, "
                        + "is_high_woman, is_high_senior, is_winner, is_runner_up, "
                        + "total_matchplay_games, total_matchplay_wins, total_stepladder_games, "
                        + "total_stepladder_wins, total_pinfall, total_games, "
                        + "total_qual_games, total_semi_games, total_qual_pinfall, total_semi_pinfall, "
                        + "total_matchplay_pinfall, total_stepladder_pinfall, highest_3_game_set, "
                        + "highest_6_game_set, highest_8_game_set, "
                        + "created_at, updated_at) VALUES( "
                    + tourneyId + ", "
                    + bowlerId + ", "
                    + e.isQualCut + ", "
                    + e.isSemiCut + ", "
                    + e.isHighWoman + ", "
                    + e.isHighSenior + ", "
                    + e.isWinner + ", "
                    + e.isSecond + ", "
                    + e.getNumMatchPlayGames() + ", "
                    + e.matchplayWins + ", "
                    + e.getNumStepLadderGames() + ", "
                    + e.stepladderWins + ", "
                    + e.getTotalPinfall() + ", "
                    + e.games.size() + ", "
                    + e.getNumQualGames() + ", "
                    + e.getNumSemiGames() + ", "
                    + e.getQualPinfall() + ", "
                    + e.getSemiPinfall() + ", "
                    + e.getMatchPlayPinfall() + ", "
                    + e.getStepLadderPinfall() + ", "
                    + e.getHighest3GameSet() + ", "
                    + e.getHighest6GameSet() + ", "
                    + e.getHighest8GameSet() + ", '"
                    + CSBTTourneyDataParser.now() + "', '"
                    + CSBTTourneyDataParser.now() + "')";
                
                st.execute(queryStr);
                
                queryStr = "SELECT LAST_INSERT_ID()";

                idrs = st.executeQuery(queryStr);

                if(idrs.next())
                {
                    entryId = idrs.getInt(1);  
                }
                
                //set this entry as the winner/runnerup/woman/senior
                if(e.isWinner)
                {
                    queryStr = "UPDATE tournaments t SET winner_id=" + entryId +
                            " WHERE t.id=" + tourneyId;
                        
                    st.execute(queryStr);
                }
                else if(e.isSecond)
                {
                    queryStr = "UPDATE tournaments t SET runner_up_id=" + entryId +
                            " WHERE t.id=" + tourneyId;
                        
                    st.execute(queryStr);
                }
                
                if(e.isHighWoman)
                {
                    queryStr = "UPDATE tournaments t SET top_woman_id=" + entryId +
                            " WHERE t.id=" + tourneyId;
                        
                    st.execute(queryStr);
                }
                if(e.isHighSenior)
                {
                    queryStr = "UPDATE tournaments t SET top_senior_id=" + entryId +
                            " WHERE t.id=" + tourneyId;
                        
                    st.execute(queryStr);
                }
                
                
                //create the games, and link to the entry
                for(Game g : e.games)
                {
                    queryStr = "INSERT INTO games(entry_id, score, gameid, created_at, updated_at) VALUES( " 
                            + entryId + ", "
                            + g.score + ", '" 
                            + g.gameId + "', '"
                            + CSBTTourneyDataParser.now() + "', '"
                            + CSBTTourneyDataParser.now() + "')";
                    
                    st.execute(queryStr);
                }
            }
            


        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
            }
        }
    }

    public static final String DATE_FORMAT_NOW = "yyyy-MM-dd HH:mm:ss";
    
    public static String now() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
        return sdf.format(cal.getTime());
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        XSSFWorkbook workBook = null;
        File file = new File("C:\\Users\\Kerpgasm\\Desktop\\KerpStandards.xlsx");
        InputStream excelDocumentStream = null;
        CSBTTourneyDataParser parser;

        try {
            excelDocumentStream = new FileInputStream(file);
            //POIFSFileSystem fsPOI = new POIFSFileSystem(new BufferedInputStream(excelDocumentStream));

            workBook = new XSSFWorkbook(excelDocumentStream);

            parser = new CSBTTourneyDataParser(workBook);
            parser.doWork();

            excelDocumentStream.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
