/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package csbttourneydataparser.data;

/**
 *
 * @author macgasm
 */
public class Game {
    public int score;
    public String gameId;
    
    public Game(int score, String gameId)
    {
        this.score = score;
        this.gameId = gameId;
    }   
}
