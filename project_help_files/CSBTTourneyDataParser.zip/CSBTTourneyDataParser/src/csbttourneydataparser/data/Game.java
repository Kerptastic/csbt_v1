/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package csbttourneydataparser.data;

/**
 *
 * @author macgasm
 */
public class Game {
    private int score;
    private String gameId;
    
    public Game(int score, String gameId)
    {
        
        this.score = score;
        this.gameId = gameId;
    }
    
    public String getGameId() {
        return gameId;
    }

    public void setGameId(String gameId) {
        this.gameId = gameId;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
