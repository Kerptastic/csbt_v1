/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package csbttourneydataparser.data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author macgasm
 */
public class Tournament {
    private String name;
    private String date;
    private String bowlingCenter;
    private String bowlingCenterURL;
    private String oilPattern;
    private String oilPatternURL;
    private String format;
    private List<Entry> entries;
    private Entry winner;
    private Entry second;
    private Entry highWoman;
    private Entry highSenior;
    
    public Tournament(String name, String date, String bowlingCenter, 
            String bowlingCenterURL, String oilPattern, String oilPatternURL,
            String format)
    {
        this.name = name;
        this.date = date;
        this.bowlingCenter = bowlingCenter;
        this.bowlingCenterURL = bowlingCenterURL;
        this.oilPattern = oilPattern;
        this.oilPatternURL = oilPatternURL;
        this.format = format;
        this.entries = new ArrayList<>();
    }

    public String getBowlingCenter() {
        return bowlingCenter;
    }

    public void setBowlingCenter(String bowlingCenter) {
        this.bowlingCenter = bowlingCenter;
    }

    public String getBowlingCenterURL() {
        return bowlingCenterURL;
    }

    public void setBowlingCenterURL(String bowlingCenterURL) {
        this.bowlingCenterURL = bowlingCenterURL;
    }

    public String getOilPatternURL() {
        return oilPatternURL;
    }

    public void setOilPatternURL(String oilPatternURL) {
        this.oilPatternURL = oilPatternURL;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public List<Entry> getEntries() {
        return entries;
    }

    public void setEntries(List<Entry> entries) {
        this.entries = entries;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOilPattern() {
        return oilPattern;
    }

    public void setOilPattern(String oilPattern) {
        this.oilPattern = oilPattern;
    }
    
    public void addEntry(Entry entry)
    {
        this.entries.add(entry);
    }

    public Entry getHighSenior() {
        return highSenior;
    }

    public void setHighSenior(Entry highSenior) {
        this.highSenior = highSenior;
    }

    public Entry getHighWoman() {
        return highWoman;
    }

    public void setHighWoman(Entry highWoman) {
        this.highWoman = highWoman;
    }

    public Entry getSecond() {
        return second;
    }

    public void setSecond(Entry second) {
        this.second = second;
    }

    public Entry getWinner() {
        return winner;
    }

    public void setWinner(Entry winner) {
        this.winner = winner;
    }
}
