/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package csbttourneydataparser.data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author macgasm
 */
public class Tournament {
    public String name;
    public String date;
    public String bowlingCenter;
    public String bowlingCenterURL;
    public String oilPattern;
    public String oilPatternURL;
    public String format;
    public List<Entry> entries;
    public Entry winner;
    public Entry second;
    public Entry highWoman;
    public Entry highSenior;
    
    public Tournament(String name, String date, String bowlingCenter, 
            String bowlingCenterURL, String oilPattern, String oilPatternURL,
            String format)
    {
        this.name = name;
        this.date = date;
        this.bowlingCenter = bowlingCenter;
        this.bowlingCenterURL = bowlingCenterURL;
        this.oilPattern = oilPattern;
        this.oilPatternURL = oilPatternURL;
        this.format = format;
        this.entries = new ArrayList<>();
    }

    public void addEntry(Entry entry)
    {
        this.entries.add(entry);
    }
}
