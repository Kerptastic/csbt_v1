/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package csbttourneydataparser.data;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author macgasm
 */
public class Bowler {
    private String firstName;
    private String lastName;
    private List<Entry> entries;
    
    public Bowler(String firstName, String lastName)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        entries = new ArrayList<>();
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public List<Entry> getEntries() {
        return entries;
    }

    public void setEntries(List<Entry> entries) {
        this.entries = entries;
    }

    public void addEntry(Entry entry)
    {
        this.entries.add(entry);
    }
}
