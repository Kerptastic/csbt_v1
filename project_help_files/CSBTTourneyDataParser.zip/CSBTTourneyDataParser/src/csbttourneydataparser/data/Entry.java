/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package csbttourneydataparser.data;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author macgasm
 */
public class Entry {
    private List<Game> games;
    private Bowler bowler;
    private boolean isQualCut;
    private boolean isSemiCut;
    private boolean isHighWoman;
    private boolean isHighSenior;
    private boolean isWinner;
    private boolean isSecond;
    
    public Entry(Bowler bowler)
    {
        this.games = new ArrayList<>();
        this.bowler = bowler;
        
        this.isQualCut = false;
        this.isSemiCut = false;
        this.isHighWoman = false;
        this.isHighSenior = false;
        this.isWinner = false;
        this.isSecond = false;
    }
    
    public void addGame(Game game)
    {
        this.games.add(game);
    }

    public Bowler getBowler() {
        return bowler;
    }

    public void setBowler(Bowler bowler) {
        this.bowler = bowler;
    }

    public List<Game> getGames() {
        return games;
    }

    public void setGames(List<Game> games) {
        this.games = games;
    }

    public boolean isIsHighSenior() {
        return isHighSenior;
    }

    public void setIsHighSenior(boolean isHighSenior) {
        this.isHighSenior = isHighSenior;
    }

    public boolean isIsHighWoman() {
        return isHighWoman;
    }

    public void setIsHighWoman(boolean isHighWoman) {
        this.isHighWoman = isHighWoman;
    }

    public boolean isIsQualCut() {
        return isQualCut;
    }

    public void setIsQualCut(boolean isQualCut) {
        this.isQualCut = isQualCut;
    }

    public boolean isIsSemiCut() {
        return isSemiCut;
    }

    public void setIsSemiCut(boolean isSemiCut) {
        this.isSemiCut = isSemiCut;
    }

    public boolean isIsSecond() {
        return isSecond;
    }

    public void setIsSecond(boolean isSecond) {
        this.isSecond = isSecond;
    }

    public boolean isIsWinner() {
        return isWinner;
    }

    public void setIsWinner(boolean isWinner) {
        this.isWinner = isWinner;
    }
    
    
    
    @Override
    public boolean equals(Object other)
    {
        if(other instanceof Entry)
        {
            Entry o = (Entry)other;
        
            return (this.bowler.getFirstName().equals(o.bowler.getFirstName()) &&
                    (this.bowler.getLastName().equals(o.bowler.getLastName())));
        }
        
        return false;
    }
}
