/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package csbttourneydataparser.data;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author macgasm
 */
public class Entry {
    public List<Game> games;
    public Bowler bowler;
    public boolean isQualCut;
    public boolean isSemiCut;
    public boolean isHighWoman;
    public boolean isHighSenior;
    public boolean isWinner;
    public boolean isSecond;
    public int matchplayWins;
    public int stepladderWins;
    
    public Entry(Bowler bowler)
    {
        this.games = new ArrayList<>();
        this.bowler = bowler;
        
        this.isQualCut = false;
        this.isSemiCut = false;
        this.isHighWoman = false;
        this.isHighSenior = false;
        this.isWinner = false;
        this.isSecond = false;
        
        this.matchplayWins = 0;
        this.stepladderWins = 0;
    }
    
    public void addGame(Game game)
    {
        this.games.add(game);
    }

    public int getTotalPinfall()
    {
        int pinfall = 0;
        
        for(Game g : this.games)
        {
            pinfall += g.score;
        }
        return pinfall;
    }
    
    public int getQualPinfall()
    {
        int pinfall = 0;
        
        for(Game g : this.games)
        {
            if(g.gameId.toLowerCase().startsWith("q"))
            {
                pinfall += g.score;
            }
        }
        
        return pinfall;
    }
    
    public int getNumQualGames()
    {
        int numGames = 0;
        
        for(Game g : this.games)
        {
            if(g.gameId.toLowerCase().startsWith("q"))
            {
                numGames++;
            }
        }
        
        return numGames;
    }
    
    public int getSemiPinfall()
    {
        int pinfall = 0;
        
        for(Game g : this.games)
        {
            if(g.gameId.toLowerCase().startsWith("se"))
            {
                pinfall += g.score;
            }
        }
        
        return pinfall;
    }
    
    public int getNumSemiGames()
    {
        int numGames = 0;
        
        for(Game g : this.games)
        {
            if(g.gameId.toLowerCase().startsWith("se"))
            {
                numGames++;
            }
        }
        
        return numGames;
    }
    
    public int getMatchPlayPinfall()
    {
        int pinfall = 0;
        
        for(Game g : this.games)
        {
            if(g.gameId.toLowerCase().startsWith("mp"))
            {
                pinfall += g.score;
            }
        }
        
        return pinfall;
    }
    
    public int getNumMatchPlayGames()
    {
        int numGames = 0;
        
        for(Game g : this.games)
        {
            if(g.gameId.toLowerCase().startsWith("mp"))
            {
                numGames++;
            }
        }
        
        return numGames;
    }
    
    public int getNumStepLadderGames()
    {
        int numGames = 0;
        
        for(Game g : this.games)
        {
            if(g.gameId.toLowerCase().startsWith("sl"))
            {
                numGames++;
            }
        }
        
        return numGames;
    }
    
    public int getStepLadderPinfall()
    {
        int pinfall = 0;
        
        for(Game g : this.games)
        {
            if(g.gameId.toLowerCase().startsWith("sl"))
            {
                pinfall += g.score;
            }
        }
        
        return pinfall;
    }
    
    public int getHighest3GameSet()
    {
        int testset = 0;
        int bestset = 0;
        
        //check qual first
        for(Game g : games)
        {
            switch(g.gameId)
            {
                case "q1":
                case "q2":
                case "q3":
                    testset += g.score;
                    break;
            }
        }
        
        if(testset > bestset)
            bestset = testset;
        
        testset = 0;
        
        for(Game g : games)
        {
            switch(g.gameId)
            {
                case "se1":
                case "se2":
                case "se3":
                    testset += g.score;
                    break;
            }
        }
        
        if(testset > bestset)
            bestset = testset;
        
        testset = 0;
        
        for(Game g : games)
        {
            switch(g.gameId)
            {
                case "sl1":
                case "sl2":
                case "sl3":
                    testset += g.score;
                    break;
            }
        }
        
         if(testset > bestset)
            bestset = testset;
        
        testset = 0;
        
        for(Game g : games)
        {
            switch(g.gameId)
            {
                case "mp1":
                case "mp2":
                case "mp3":
                    testset += g.score;
                    break;
            }
        }
        
        if(testset > bestset)
            bestset = testset;
        
        return bestset;
    }
    
    public int getHighest6GameSet()
    {
        int testset = 0;
        int bestset = 0;
        
        //check qual first
        for(Game g : games)
        {
            switch(g.gameId)
            {
                case "q1":
                case "q2":
                case "q3":
                case "q4":
                case "q5":
                case "q6":
                    testset += g.score;
                    break;
            }
        }
        
        if(testset > bestset)
            bestset = testset;
        
        testset = 0;
        
        for(Game g : games)
        {
            switch(g.gameId)
            {
                case "se1":
                case "se2":
                case "se3":
                case "se4":
                case "se5":
                case "se6":
                    testset += g.score;
                    break;
            }
        }
        
        if(testset > bestset)
            bestset = testset;
        
        testset = 0;
        
        for(Game g : games)
        {
            switch(g.gameId)
            {
                case "sl1":
                case "sl2":
                case "sl3":
                case "sl4":
                case "sl5":
                case "sl6":
                    testset += g.score;
                    break;
            }
        }
        
        testset = 0;
        
        for(Game g : games)
        {
            switch(g.gameId)
            {
                case "mp1":
                case "mp2":
                case "mp3":
                case "mp4":
                case "mp5":
                case "mp6":
                    testset += g.score;
                    break;
            }
        }
        
        if(testset > bestset)
            bestset = testset;
        
        return bestset;
    }
    
    public int getHighest8GameSet()
    {
        int testset = 0;
        int bestset = 0;
        
        //check qual first
        for(Game g : games)
        {
            switch(g.gameId)
            {
                case "q1":
                case "q2":
                case "q3":
                case "q4":
                case "q5":
                case "q6":
                case "q7":
                case "q8":
                    testset += g.score;
                    break;
            }
        }
        
        if(testset > bestset)
            bestset = testset;
        
        testset = 0;
        
        for(Game g : games)
        {
            switch(g.gameId)
            {
                case "se1":
                case "se2":
                case "se3":
                case "se4":
                case "se5":
                case "se6":
                case "se7":
                case "se8":
                    testset += g.score;
                    break;
            }
        }
        
        if(testset > bestset)
            bestset = testset;
        
        testset = 0;
        
        for(Game g : games)
        {
            switch(g.gameId)
            {
                case "sl1":
                case "sl2":
                case "sl3":
                case "sl4":
                case "sl5":
                case "sl6":
                case "sl7":
                case "sl8":
                    testset += g.score;
                    break;
            }
        }
        
        if(testset > bestset)
            bestset = testset;
        
        testset = 0;
        
        for(Game g : games)
        {
            switch(g.gameId)
            {
                case "mp1":
                case "mp2":
                case "mp3":
                case "mp4":
                case "mp5":
                case "mp6":
                case "mp7":
                case "mp8":
                    testset += g.score;
                    break;
            }
        }
        
        if(testset > bestset)
            bestset = testset;
        
        return bestset;
    }
    
    @Override
    public boolean equals(Object other)
    {
        if(other instanceof Entry)
        {
            Entry o = (Entry)other;
        
            return (this.bowler.firstName.equals(o.bowler.firstName) &&
                    (this.bowler.lastName.equals(o.bowler.lastName)));
        }
        
        return false;
    }
}
